| profile                                     | relation        |   episodes |   reports |   converted |   declined_share |
|:--------------------------------------------|:----------------|-----------:|----------:|------------:|-----------------:|
| +1 dB, Hys 1, TTT 320, RI 240 x infinity    | intra-frequency |        734 |      1622 |         717 |           0.0232 |
| -15 dB, Hys 1, TTT 160, RI 5120 x infinity  | intra-frequency |        543 |      1355 |         274 |           0.4954 |
| -10 dB, Hys 2, TTT 640, RI 5120 x infinity  | intra-frequency |        431 |      2267 |         315 |           0.2691 |
| -10 dB, Hys 2, TTT 640, RI 5120 x r1        | intra-frequency |        278 |       317 |         113 |           0.5935 |
| -15 dB, Hys 1, TTT 160, RI 2048 x infinity  | intra-frequency |        242 |      2013 |         141 |           0.4174 |
| -15 dB, Hys 1, TTT 320, RI 5120 x infinity  | intra-frequency |         38 |        82 |          20 |           0.4737 |
| -6.5 dB, Hys 2, TTT 640, RI 5120 x infinity | intra-frequency |         25 |       105 |          19 |           0.24   |
| -15 dB, Hys 1, TTT 160, RI 5120 x infinity  | inter-frequency |         16 |        29 |           7 |           0.5625 |
| +2 dB, Hys 1, TTT 320, RI 240 x infinity    | intra-frequency |         15 |        32 |          15 |           0      |
| +1 dB, Hys 1, TTT 320, RI 240 x infinity    | inter-frequency |         12 |        15 |          12 |           0      |
| -10 dB, Hys 2, TTT 640, RI 5120 x infinity  | inter-frequency |         12 |        52 |           6 |           0.5    |
| -10 dB, Hys 2, TTT 640, RI 5120 x r1        | inter-frequency |          6 |         6 |           1 |           0.8333 |
| +2 dB, Hys 1, TTT 640, RI 240 x infinity    | intra-frequency |          4 |        10 |           4 |           0      |
| -6.5 dB, Hys 2, TTT 640, RI 5120 x infinity | inter-frequency |          2 |         8 |           2 |           0      |
| +5 dB, Hys 2, TTT 640, RI 5120 x infinity   | intra-frequency |          1 |         2 |           0 |           1      |
| -15 dB, Hys 1, TTT 320, RI 2048 x infinity  | intra-frequency |          1 |         1 |           1 |           0      |
| -15 dB, Hys 1, TTT 320, RI 5120 x infinity  | inter-frequency |          1 |         1 |           0 |           1      |