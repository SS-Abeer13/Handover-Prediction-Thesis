| stratum                   |   n_handovers |   rate |
|:--------------------------|--------------:|-------:|
| intra-frequency handovers |           748 | 0.2714 |
| inter-frequency handovers |           209 | 0.0718 |
| highway campaign          |           177 | 0.322  |
| urban campaigns           |           780 | 0.25   |