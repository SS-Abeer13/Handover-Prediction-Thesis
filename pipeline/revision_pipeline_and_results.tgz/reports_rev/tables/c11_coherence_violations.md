| arm                          |   rows_violating |   pairs_violating |   mean_violation_if_any |   p95_violation_if_any |   max_violation |
|:-----------------------------|-----------------:|------------------:|------------------------:|-----------------------:|----------------:|
| independent                  |           0.29   |            0.0797 |                  0.0199 |                 0.1018 |          0.3774 |
| independent + cumulative max |           0      |            0      |                  0      |                 0      |          0      |
| independent + PAV            |           0      |            0      |                  0      |                 0      |          0      |
| independent + isotonic       |           0.3343 |            0.0947 |                  0.0212 |                 0.0688 |          0.4163 |
| independent + isotonic + PAV |           0      |            0      |                  0      |                 0      |          0      |
| hazard                       |           0      |            0      |                  0      |                 0      |          0      |