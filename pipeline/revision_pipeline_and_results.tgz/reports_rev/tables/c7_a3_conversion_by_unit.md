| unit                 | stratum                  |    n |   converted |   declined_share |
|:---------------------|:-------------------------|-----:|------------:|-----------------:|
| per report (v1 unit) | pooled                   | 8136 |        3006 |           0.6305 |
| per report (v1 unit) | 10 Sept (urban arterial) | 2287 |         980 |           0.5715 |
| per report (v1 unit) | 12 Sept (urban loop)     | 1857 |         716 |           0.6144 |
| per report (v1 unit) | 13 Sept (dense urban)    | 2215 |         806 |           0.6361 |
| per report (v1 unit) | 15 Sept (highway)        | 1777 |         504 |           0.7164 |
| per report (v1 unit) | inter-frequency          |   93 |          34 |           0.6344 |
| per report (v1 unit) | intra-frequency          | 8043 |        2972 |           0.6305 |
| per trigger episode  | pooled                   | 2361 |        1647 |           0.3024 |
| per trigger episode  | 10 Sept (urban arterial) |  726 |         531 |           0.2686 |
| per trigger episode  | 12 Sept (urban loop)     |  476 |         349 |           0.2668 |
| per trigger episode  | 13 Sept (dense urban)    |  740 |         480 |           0.3514 |
| per trigger episode  | 15 Sept (highway)        |  419 |         287 |           0.315  |
| per trigger episode  | inter-frequency          |   49 |          28 |           0.4286 |
| per trigger episode  | intra-frequency          | 2312 |        1619 |           0.2997 |