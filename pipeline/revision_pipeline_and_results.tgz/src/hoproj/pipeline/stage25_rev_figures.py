"""Stage 25 - figures for the revised manuscript, drawn only from reports_rev/tables."""
from __future__ import annotations

from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

T = Path("reports_rev/tables")
F = Path("reports_rev/figures")
F.mkdir(parents=True, exist_ok=True)
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 9, "axes.spines.top": False,
                     "axes.spines.right": False, "figure.dpi": 200, "savefig.bbox": "tight"})
C = ["#1f4e79", "#c0504d", "#4f9a5a", "#e3a21a", "#7a5195", "#5b8db8", "#8c8c8c", "#b5651d",
     "#2a9d8f", "#6d6d6d"]
H = [0.5, 1, 2, 3, 5]


def t(name):
    return pd.read_csv(T / f"{name}.csv")


def fig_alignment():
    a = t("c9_row_alignment_audit")
    b = t("c9ext_cell_contamination").iloc[0]
    fig, axes = plt.subplots(1, 2, figsize=(7.4, 2.9),
                             gridspec_kw={"width_ratios": [2.1, 1]})
    ax = axes[0]
    cols = [c for c in a.columns if c.startswith("row")]
    x = np.arange(len(cols))
    for i, r in a.iterrows():
        ax.bar(x + (i - 0.5) * 0.38, [r[c] for c in cols], 0.38, color=C[i], label=r["subset"])
    ax.set_xticks(x, ["t−3", "t−2", "t−1", "t", "t+1"])
    ax.set_title("this work, XCAL 1 Hz export\n(row relative to the handover command)", fontsize=8.5)
    ax.set_ylabel("share of events whose target\ncell already serves")
    ax.axvspan(2.5, 3.5, color="#f3d9d9", zorder=-1)
    ax.legend(frameon=False, fontsize=7.5)
    ax.set_ylim(0, 1)
    ax2 = axes[1]
    share = float(b.share_closer_to_new_cell)
    ax2.bar([0, 1], [float(a.iloc[0]["row t+0"]), share], 0.55, color=[C[0], C[2]])
    ax2.axhline(0.5, ls=":", color="k", lw=0.9)
    ax2.set_xticks([0, 1], ["XCAL\n(this work)", "G-NetTrack Pro\n(public, MMSys 2020)"], fontsize=7.5)
    ax2.set_ylabel("row t already shows\nthe post-event cell")
    ax2.set_ylim(0, 1)
    ax2.set_title("the same check, two instruments", fontsize=8.5)
    for i, v in enumerate([float(a.iloc[0]["row t+0"]), share]):
        ax2.text(i, v + 0.03, f"{v:.0%}", ha="center", fontsize=8)
    fig.savefig(F / "fig_c9_alignment.png")


def fig_profiles():
    p = t("c5_handover_profiles_v2")
    g = p.groupby("profile")["handovers"].sum().sort_values(ascending=True).tail(10)
    fig, ax = plt.subplots(figsize=(6.4, 3.2))
    col = [C[0] if s.startswith("A3 +") else (C[1] if s.startswith("A3 -") else C[6]) for s in g.index]
    ax.barh(g.index, g.values, color=col)
    ax.set_xlabel("handovers attributed (latest report within 2 s of the command)")
    for y, v in enumerate(g.values):
        ax.text(v + 4, y, f"{v} ({v / p.handovers.sum():.0%})", va="center", fontsize=8)
    fig.savefig(F / "fig_c5_profiles.png")


def fig_protocols():
    s = t("c2_protocol_ladder")
    order = ["random_row", "chunk_grouped", "blocked_purged", "loco"]
    lab = ["random rows", "random 180 s\nchunks (v1)", "blocks +\n60 s purge", "leave one\ncapture out"]
    fig, axes = plt.subplots(1, 2, figsize=(7.2, 3.0))
    for ax, h in zip(axes, (1.0, 5.0)):
        for i, (L, g) in enumerate(s[s.horizon_s == h].groupby("learner")):
            g = g.set_index("protocol").reindex(order)
            ax.plot(range(4), g["auprc"], marker="o", color=C[i % len(C)], label=L)
        ax.set_xticks(range(4), lab, fontsize=7.5)
        ax.set_title(f"AUPRC at {h:g} s", fontsize=9)
        ax.axhline(t("c4_prevalence").set_index("horizon_s").loc[h, "prevalence"], ls=":", color="k", lw=0.8)
    axes[1].legend(frameon=False, fontsize=7, loc="upper right")
    fig.savefig(F / "fig_c2_protocols.png")


def fig_main():
    m = t("c3_main_loco")
    prev = t("c4_prevalence")
    fig, ax = plt.subplots(figsize=(6.4, 3.4))
    for i, (L, g) in enumerate(m.groupby("learner", sort=False)):
        ax.plot(g.horizon_s, g.lift, marker="o", color=C[i % len(C)], label=L)
    ax.axhline(1, ls=":", color="k", lw=0.8)
    ax.set_xlabel("horizon (s)")
    ax.set_ylabel("AUPRC lift over prevalence")
    ax.legend(frameon=False, fontsize=7, ncol=2)
    fig.savefig(F / "fig_c3_main.png")


def fig_per_capture():
    m = t("c3_main_loco_per_capture")
    m = m[m.horizon_s == 1.0]
    fig, ax = plt.subplots(figsize=(6.4, 3.2))
    learners = list(dict.fromkeys(m.learner))
    for j, cap in enumerate(sorted(m.held_out_capture.unique())):
        g = m[m.held_out_capture == cap].set_index("learner").reindex(learners)
        ax.scatter(range(len(learners)), g["lift"], color=C[j], label=cap, s=18)
    ax.set_xticks(range(len(learners)), learners, rotation=40, ha="right", fontsize=7)
    ax.set_ylabel("AUPRC lift at 1 s")
    ax.axhline(1, ls=":", color="k", lw=0.8)
    ax.legend(frameon=False, fontsize=7)
    fig.savefig(F / "fig_c3_per_capture.png")


def fig_bursts():
    s = t("c8_burst_strata")
    s = s[s.learner.isin(["LightGBM", "Dwell time only (LightGBM)", "Event A3 rule (deployed parameters)"])]
    fig, axes = plt.subplots(1, 2, figsize=(7.2, 2.9), sharey=True)
    for ax, (st, g) in zip(axes, s.groupby("stratum")):
        for i, (L, gg) in enumerate(g.groupby("learner")):
            ax.plot(gg.horizon_s, gg.lift, marker="o", color=C[i], label=L)
        ax.set_title(st, fontsize=8.5)
        ax.axhline(1, ls=":", color="k", lw=0.8)
        ax.set_xlabel("horizon (s)")
    axes[0].set_ylabel("AUPRC lift")
    axes[1].legend(frameon=False, fontsize=7)
    fig.savefig(F / "fig_c8_bursts.png")


def fig_dwell():
    d = t("c8_dwell_direction")
    fig, ax = plt.subplots(figsize=(6.4, 2.8))
    ax.plot(range(len(d)), d.p_ho_1s, marker="o", color=C[0], label="P(handover within 1 s)")
    ax.plot(range(len(d)), d.p_ho_5s, marker="s", color=C[1], label="P(handover within 5 s)")
    ax.set_xticks(range(len(d)), d.dwell_bin, rotation=30, fontsize=7)
    ax.set_xlabel("time since previous handover command (s)")
    ax.legend(frameon=False, fontsize=8)
    fig.savefig(F / "fig_c8_dwell.png")


def fig_coherence():
    m = t("c11_coherence_metrics")
    v = t("c11_coherence_violations")
    fig, axes = plt.subplots(1, 2, figsize=(7.2, 2.9))
    for i, (a, g) in enumerate(m.groupby("arm", sort=False)):
        axes[0].plot(g.horizon_s, g.ece, marker="o", color=C[i], label=a)
    axes[0].set_xlabel("horizon (s)")
    axes[0].set_ylabel("ECE")
    axes[0].legend(frameon=False, fontsize=6.5)
    axes[1].barh(v.arm, 100 * v.rows_violating, color=C[: len(v)])
    axes[1].set_xlabel("% of rows with an ordering violation")
    axes[1].tick_params(axis="y", labelsize=7)
    fig.savefig(F / "fig_c11_coherence.png")


def fig_crc():
    s = t("c10_crc_frontier")
    ex = t("c10_crc_pooled_chunk_split") if (T / "c10_crc_pooled_chunk_split.csv").exists() else None
    fig, axes = plt.subplots(1, 2, figsize=(7.2, 3.0))
    for i, (h, g) in enumerate(s.groupby("horizon_s")):
        axes[0].plot(g.alpha, g.mean_unit_loss, marker="o", color=C[i], label=f"cross-capture, {h:g} s")
        axes[1].plot(g.alpha, g.alarm_rate_mean, marker="o", color=C[i], label=f"cross-capture, {h:g} s")
        if ex is not None:
            e = ex[ex.horizon_s == h]
            axes[0].plot(e.alpha, e.mean_unit_loss, marker="s", ls="--", color=C[i], label=f"pooled chunks, {h:g} s")
            axes[1].plot(e.alpha, e.alarm_rate, marker="s", ls="--", color=C[i])
    axes[0].plot([0, 0.32], [0, 0.32], color="k", lw=0.8)
    axes[0].set_xlabel("target α")
    axes[0].set_ylabel("realised mean per-chunk miss rate")
    axes[1].set_xlabel("target α")
    axes[1].set_ylabel("share of rows alarmed")
    axes[0].legend(frameon=False, fontsize=6.5)
    fig.savefig(F / "fig_c10_crc.png")


def fig_external():
    e = t("c6_external_signalling_only")
    e = e[e.horizon_s == 1.0]
    fig, ax = plt.subplots(figsize=(6.4, 2.6))
    y = np.arange(len(e))
    ax.errorbar(e.auroc, y, xerr=[e.auroc - e.auroc_ci_low, e.auroc_ci_high - e.auroc], fmt="o", color=C[0])
    ax.set_yticks(y, e.setting)
    ax.axvline(0.5, ls=":", color="k", lw=0.8)
    ax.set_xlabel("AUROC at 1 s (95 % run-bootstrap interval)")
    fig.savefig(F / "fig_c6_external.png")


def fig_single():
    s = t("c14_single_feature_auroc").head(12).iloc[::-1]
    fig, ax = plt.subplots(figsize=(6.4, 3.2))
    ax.barh(s.feature, s.auroc_1s, color=C[0])
    ax.set_xlim(0.5, max(0.8, s.auroc_1s.max() + 0.02))
    ax.set_xlabel("single-feature AUROC at 1 s (orientation-free, lagged export)")
    ax.tick_params(axis="y", labelsize=7)
    fig.savefig(F / "fig_c14_single.png")


def fig_conversion():
    c = t("c7_a3_conversion_by_unit")
    c = c[~c.stratum.isin(["intra-frequency", "inter-frequency"])]
    fig, ax = plt.subplots(figsize=(6.4, 2.8))
    strata = list(dict.fromkeys(c.stratum))
    x = np.arange(len(strata))
    for i, (u, g) in enumerate(c.groupby("unit")):
        g = g.set_index("stratum").reindex(strata)
        ax.bar(x + (i - 0.5) * 0.38, 100 * g.declined_share, 0.38, color=C[i], label=u)
    ax.set_xticks(x, strata, fontsize=7.5, rotation=15)
    ax.set_ylabel("% not followed by a\nhandover within 2 s")
    ax.legend(frameon=False, fontsize=8)
    fig.savefig(F / "fig_c7_conversion.png")


def fig_ablation():
    a = t("c18_ablation")
    a = a[a.horizon_s.isin([1.0, 5.0])]
    fig, ax = plt.subplots(figsize=(6.4, 3.2))
    vs = list(dict.fromkeys(a.variant))
    y = np.arange(len(vs))
    for i, h in enumerate((1.0, 5.0)):
        g = a[a.horizon_s == h].set_index("variant").reindex(vs)
        ax.barh(y + (i - 0.5) * 0.38, g.lift_mean, 0.38, xerr=g.lift_std, color=C[i], label=f"{h:g} s")
    ax.set_yticks(y, vs, fontsize=7)
    ax.axvline(1, ls=":", color="k", lw=0.8)
    ax.set_xlabel("AUPRC lift (LOCO, mean ± sd over 3 seeds)")
    ax.legend(frameon=False)
    fig.savefig(F / "fig_c18_ablation.png")


def fig_events():
    e = t("c18_event_metrics_pooled_fpr5")
    fig, ax = plt.subplots(figsize=(6.4, 2.8))
    ax.plot(e.horizon_s, 100 * e.detection_rate, marker="o", color=C[0], label="events detected")
    ax.plot(e.horizon_s, 100 * e.grid_ceiling, marker="s", ls="--", color=C[6], label="1 Hz grid ceiling")
    ax.set_xlabel("horizon (s)")
    ax.set_ylabel("% of handover events")
    ax2 = ax.twinx()
    ax2.plot(e.horizon_s, e.false_alarms_per_hour, marker="^", color=C[1], label="false alarms / h")
    ax2.set_ylabel("false-alarm episodes per hour", color=C[1])
    ax.legend(frameon=False, fontsize=8, loc="upper left")
    fig.savefig(F / "fig_c18_events.png")


def fig_protocol_diagram():
    fig, ax = plt.subplots(figsize=(6.4, 2.2))
    ax.axis("off")
    caps = ["10 Sept", "12 Sept", "13 Sept", "15 Sept"]
    widths = [45, 24, 60, 42]
    x0 = 0
    for i, (c, w) in enumerate(zip(caps, widths)):
        for j, (y, lab) in enumerate(((1.6, "LOCO"), (0.6, "blocked"))):
            if lab == "LOCO":
                col = C[1] if i == 3 else C[0]
                ax.add_patch(plt.Rectangle((x0, y), w, 0.6, color=col, alpha=0.85))
            else:
                for b in range(5):
                    bw = w / 5
                    col = C[1] if b == 2 else C[0]
                    ax.add_patch(plt.Rectangle((x0 + b * bw, y), bw, 0.6, color=col, alpha=0.85))
                    if b in (1, 3):
                        ax.add_patch(plt.Rectangle((x0 + (b + (1 if b == 1 else 0)) * bw - (1 if b == 1 else 0),
                                                    y), 1, 0.6, color="white"))
        ax.text(x0 + w / 2, 2.35, c, ha="center", fontsize=8)
        x0 += w + 3
    ax.text(-2, 1.9, "leave one capture out\n(one fold shown)", ha="right", va="center", fontsize=7.5)
    ax.text(-2, 0.9, "contiguous blocks,\n60 s purge (fold 3)", ha="right", va="center", fontsize=7.5)
    ax.set_xlim(-45, x0)
    ax.set_ylim(0.3, 2.6)
    fig.savefig(F / "fig_c1_protocols.png")


def fig_paired_ece():
    m = t("c3_main_loco_per_capture")
    c = t("c11_coherence_per_capture") if (T / "c11_coherence_per_capture.csv").exists() else None
    fig, ax = plt.subplots(figsize=(5.4, 3.2))
    if c is None:
        m = m[(m.horizon_s == 1.0) & m.learner.isin(["LightGBM", "LightGBM (independent heads)"])]
        arms = ["LightGBM (independent heads)", "LightGBM"]
    else:
        m, arms = c[c.horizon_s == 1.0], ["independent", "hazard"]
    caps = sorted(m.iloc[:, 1].unique())
    for j, cap in enumerate(caps):
        g = m[m.iloc[:, 1] == cap].set_index(m.columns[0]).reindex(arms)
        ax.plot([0, 1], g["ece"], marker="o", color=C[j], label=cap)
    ax.set_xticks([0, 1], ["independent heads", "hazard"], fontsize=8)
    ax.set_ylabel("ECE at 1 s")
    ax.legend(frameon=False, fontsize=7)
    fig.savefig(F / "fig_c11_paired.png")


def fig_loco():
    m = t("c3_main_loco_per_capture")
    p = t("c3_main_loco")
    m, p = m[(m.horizon_s == 1.0) & (m.learner == "LightGBM")], p[(p.horizon_s == 1.0) & (p.learner == "LightGBM")]
    fig, axes = plt.subplots(1, 4, figsize=(7.6, 2.6))
    for ax, col, lab in zip(axes, ["auprc", "lift", "auroc", "ece"],
                            ["AUPRC", "lift over prevalence", "AUROC", "ECE"]):
        ax.bar(range(len(m)), m[col], color=[C[1] if "highway" in c else C[0] for c in m.held_out_capture])
        ax.axhline(p[col].iloc[0], ls="--", color="k", lw=0.9)
        ax.set_xticks(range(len(m)), [c.split(" ")[0] + " " + c.split(" ")[1] for c in m.held_out_capture],
                      rotation=45, ha="right", fontsize=7)
        ax.set_title(lab, fontsize=9)
    fig.savefig(F / "fig_c3_loco.png")


def fig_hazard_schematic():
    v = t("c11_coherence_violations").set_index("arm")
    rng = np.random.default_rng(3)
    H = [0.5, 1, 2, 3, 5]
    fig, axes = plt.subplots(1, 2, figsize=(6.6, 2.8), sharey=True)
    base = np.array([0.05, 0.09, 0.16, 0.22, 0.32])
    for i in range(6):
        ind = np.clip(base + rng.normal(0, 0.035, 5), 0, 1)
        axes[0].plot(H, ind, marker="o", color=C[i % len(C)], lw=1, alpha=0.85)
        haz = 1 - np.cumprod(1 - np.clip(np.diff(np.r_[0, base]) + rng.normal(0, 0.01, 5), 1e-3, 1))
        axes[1].plot(H, haz, marker="o", color=C[i % len(C)], lw=1, alpha=0.85)
    axes[0].set_title(f"five independent classifiers\n({v.loc['independent', 'rows_violating']:.1%} of rows "
                      "violate ordering)", fontsize=8.5)
    axes[1].set_title("one hazard model\n(ordering holds by construction)", fontsize=8.5)
    for ax in axes:
        ax.set_xlabel("horizon (s)")
    axes[0].set_ylabel("P(handover within h)")
    fig.savefig(F / "fig_c11_schematic.png")



if __name__ == "__main__":
    for f in [fig_alignment, fig_profiles, fig_protocols, fig_main, fig_per_capture, fig_bursts,
              fig_dwell, fig_coherence, fig_crc, fig_external, fig_single, fig_conversion,
              fig_ablation, fig_events, fig_protocol_diagram, fig_paired_ece, fig_loco,
              fig_hazard_schematic]:
        try:
            f()
            print("ok", f.__name__)
        except FileNotFoundError as e:
            print("missing table for", f.__name__, e)
        plt.close("all")